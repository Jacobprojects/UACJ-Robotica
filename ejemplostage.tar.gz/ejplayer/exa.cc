#include <iostream>
#include <libplayerc++/playerc++.h>

int main(int argc, char *argv[]) {
  using namespace PlayerCc;

  PlayerClient    robot("localhost", 6665);
  Position2dProxy p2dProxy(&robot,0);

  robot.Read();
  p2dProxy.SetSpeed(0.3, 0, -0.25); // X (m/s), Yaw (rad/s)

for(int i=0;i<1000;i++) {
  robot.Read();
  std::cout << "Iter "<<i<<std::endl;
   
  std::cout << "XPos = " << p2dProxy.GetXPos() << " m, " <<
               "YPos = " << p2dProxy.GetYPos() << " m, " <<
               "Yaw = " << p2dProxy.GetYaw() << " rad"<< std::endl;
}

 return 0;
}

